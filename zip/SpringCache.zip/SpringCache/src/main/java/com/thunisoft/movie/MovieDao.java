package com.thunisoft.movie;

public interface MovieDao{
	
	Movie findByDirector(String name);
	void updateAll();
}