package com.thunisoft.spring.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class EmployeeAspectJoinPoint {

	
	@Before("execution(public void com.thunisoft.spring.model..set*(*))")
	public void loggingAdvice(JoinPoint joinPoint){
		System.out.println("Before running loggingAdvice on method="+joinPoint.toString());
		
		System.out.println("Agruments Passed=" + Arrays.toString(joinPoint.getArgs()));

	}
	
	//Advice arguments, will be applied to bean methods with single String argument
	@Before(value = "execution(public void com.thunisoft.spring.model..set*(*)) && args(name1)",argNames = "name1")
	public void logStringArguments(String name1){
		System.out.println("String argument passed="+name1);
	}
}
