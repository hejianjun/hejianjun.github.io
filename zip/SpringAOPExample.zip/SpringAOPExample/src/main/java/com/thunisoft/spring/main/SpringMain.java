package com.thunisoft.spring.main;

import com.thunisoft.spring.model.Employee;
import com.thunisoft.spring.service.EmployeeService;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class SpringMain {

    public static void main(String[] args) {
        //ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
        //EmployeeService employeeService = ctx.getBean("employeeService", EmployeeService.class);

        //System.out.println(employeeService.getEmployee().getName());

        //employeeService.getEmployee().setName("Pankaj");

		//employeeService.getEmployee().throwException();
        //Employee employee = ctx.getBean("employee", Employee.class);
        Employee employee = new Employee();
        System.out.println(employee.getName());
        employee.setName("xx");

        //ctx.close();
    }

}
