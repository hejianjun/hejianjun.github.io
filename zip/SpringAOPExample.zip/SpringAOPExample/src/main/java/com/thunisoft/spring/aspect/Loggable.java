package com.thunisoft.spring.aspect;

public @interface Loggable {

}
